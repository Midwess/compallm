# Linear capture references

These local references were reconstructed from the two supplied `.h2d` exports. They supersede the approximate measurements used in Penpot frame 15.

Open **preferences.html** or **applications.html** for the browser reference. Both are self-contained and embed the font files from the capture. The matching PNGs are browser-rendered previews. The HTML uses fixed captured positions, so it is a visual comparison rather than application component code. The SVGs contain outlined body text shaped from those fonts and can be used as portable vector comparisons; they do not provide editable text. Nested SVG artwork and shadow rendering can vary between importers, so use the HTML and PNG for visual comparison. Browser checks in `verification.json` confirm the capture dimensions, select geometry, helper weight, loaded fonts, and zero external requests.

The files show the captured 640 px content column. The original capture coordinates and the 1496 × 1079 viewport are recorded in `measurements.json`; the browser sidebar and app shell were outside the supplied selection. The JSON capture files retain the node hierarchy, text, and styles while omitting embedded font bytes already contained in the HTML/SVG.

## Corrections established by the capture

| Detail | Captured reference |
| --- | --- |
| Switch | 30 × 20 track; 14 × 14 thumb; 3 px inset; 42 × 32 hit area |
| Select disclosure | 10 × 5 px, with the captured path |
| Helper typography | Inter Variable at weight 450 |
| Title | 24/32 px, weight 500, −0.16 px letter spacing |
| Groups | 10 px corners, half-pixel edge, 12 px between groups within Interface |
| Rows | 16 px padding, 12 px between copy and control, 3 px label/helper gap |
| Appearance | Separate System preference, Light, and Dark rows |
| Code preview | Berkeley Mono, actual syntax spans and line-number positions |
| Font settings | Collapsed 60 px row in this capture; the previous demo showed an expanded state |
| Diagram | Captured 267 px group with the hand-drawn preview |
| Application form | 32 px inputs, 64 px textareas, 8 px corners, 0.5 px border, 6 × 12 px padding |

## Combined reference frame

Open **combined-frame.html** for the three captures together at their captured sizes. **combined-frame.png** provides the full overview, and **combined-frame-manifest.json** records source hashes and panel positions. The Inbox capture is navigation only; no message pane is invented.

The Penpot Design foundations page now contains one **10 · UI reference / Linear + GitHub** frame. It has editable capture-derived controls and text; the diagram is a captured preview image. Manual Linear study boards 10–15, the partial import board, and two stray import layers were removed after saving a named version. Original Compallm foundations and other design pages remain intact.

The source `.h2d` files remain in Downloads. No application behavior or database configuration changed.

## Application form adaptation

The current Create application panel uses the GitHub new-repository H2D layout hierarchy with Linear field colors, borders, and 8 px corners. Open **application-form.html** for the adapted form. **applications.html** remains the original Linear capture for comparison. The combined frame now shows the adaptation. Shared field styling is also applied to existing Penpot field designs, preserving focus/error states and authentication sizing.
